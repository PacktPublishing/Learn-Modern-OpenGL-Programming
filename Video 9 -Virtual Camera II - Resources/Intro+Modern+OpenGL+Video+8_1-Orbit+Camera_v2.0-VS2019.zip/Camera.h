//-----------------------------------------------------------------------------
// Camera.h by Steve Jones 
// Copyright (c) 2015-2019 Game Institute. All Rights Reserved.
//
// Basic camera class including derived orbit-style camera support
//-----------------------------------------------------------------------------
#ifndef CAMERA_H
#define CAMERA_H

#include "glm/glm.hpp"

//--------------------------------------------------------------
// Camera Base Class
//--------------------------------------------------------------
class Camera
{
public:

	virtual void setPosition(const glm::vec3& position) {}
	glm::mat4 getViewMatrix() const;
	virtual void rotate(float yaw, float pitch) {}  // in degrees

protected:
	Camera();

	virtual void updateCameraVectors() {}

	glm::vec3 mPosition;
	glm::vec3 mTargetPos;
	glm::vec3 mUp;


	// Euler Angles (in radians)
	float mYaw;
	float mPitch;
};

//--------------------------------------------------------------
// Orbit Camera Class
//--------------------------------------------------------------
class OrbitCamera : public Camera
{
public:

	OrbitCamera();
	
	virtual void setPosition(const glm::vec3& position);
	virtual void rotate(float yaw, float pitch);    // in degrees

	// Camera Controls
	void setLookAt(const glm::vec3& target);
	void setRadius(float radius);

private:

	void updateCameraVectors();
	
	float mRadius;
};
#endif //CAMERA_H
